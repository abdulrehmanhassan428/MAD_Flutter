
import 'dart:async';
import 'package:flutter/material.dart';

const String studentName = 'Abdul Rehman Hassan';
const String rollNo = '04072313030';

const int seed = 30;
const int t = seed ~/ 10;
const int u = seed % 10;

const String course = 'Mobile Dev';

const int startCount = t;
const int stepSize = u == 0 ? 1 : u;
const int maxCount = seed;
const int bugStep = u == 0 ? 1 : u;
const int startSeconds = 10;

final List<String> lifecycleLog = [];

void main() {
  runApp(const LabApp());
}

class LabApp extends StatelessWidget {
  const LabApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'Study Tracker',
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Study Tracker: $course'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const StudentCard(
              name: studentName,
              roll: rollNo,
              course: course,
            ),
            const SizedBox(height: 12),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: const [
                Text(
                  'Start: $startCount',
                  key: Key('info-start'),
                ),
                Text(
                  'Step: $stepSize',
                  key: Key('info-step'),
                ),
                Text(
                  'Max: $maxCount',
                  key: Key('info-max'),
                ),
              ],
            ),

            const SizedBox(height: 20),
            const Tally(),
            const SizedBox(height: 20),
            const Countdown(),
            const SizedBox(height: 20),
            const BuggyCounter(),
          ],
        ),
      ),
    );
  }
}

class StudentCard extends StatelessWidget {
  final String name;
  final String roll;
  final String course;

  const StudentCard({
    super.key,
    required this.name,
    required this.roll,
    required this.course,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Name: $name',
              key: const Key('student-name'),
            ),
            Text(
              'Roll no: $roll',
              key: const Key('student-roll'),
            ),
            Text(
              'Course: $course',
              key: const Key('student-course'),
            ),
          ],
        ),
      ),
    );
  }
}

class GoalBanner extends StatelessWidget {
  final int count;
  final int max;

  const GoalBanner({
    super.key,
    required this.count,
    required this.max,
  });

  @override
  Widget build(BuildContext context) {
    final int percent = count * 100 ~/ max;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Text(
        'Progress: $count of $max ($percent%)',
        key: const Key('progress'),
        style: const TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}

class Tally extends StatefulWidget {
  const Tally({super.key});

  @override
  State<Tally> createState() => _TallyState();
}

class _TallyState extends State<Tally> {
  int _count = startCount;

  void _plus() {
    setState(() {
      _count = (_count + stepSize).clamp(0, maxCount);
    });
  }

  void _minus() {
    setState(() {
      _count = (_count - stepSize).clamp(0, maxCount);
    });
  }

  void _reset() {
    setState(() {
      _count = startCount;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Study Tally',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Count: $_count',
              key: const Key('count'),
              style: const TextStyle(fontSize: 18),
            ),
            GoalBanner(
              count: _count,
              max: maxCount,
            ),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                ElevatedButton(
                  key: const Key('plus'),
                  onPressed: _count < maxCount ? _plus : null,
                  child: Text('+$stepSize'),
                ),
                ElevatedButton(
                  key: const Key('minus'),
                  onPressed: _count > 0 ? _minus : null,
                  child: Text('-$stepSize'),
                ),
                OutlinedButton(
                  key: const Key('reset'),
                  onPressed: _reset,
                  child: const Text('Reset'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class BuggyCounter extends StatefulWidget {
  const BuggyCounter({super.key});

  @override
  State<BuggyCounter> createState() => _BuggyCounterState();
}

class _BuggyCounterState extends State<BuggyCounter> {
  int _clicks = 0;

  void _click() {
    setState(() {
      _clicks += bugStep;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Button Counter',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Buggy Counter: $_clicks',
              key: const Key('buggy-count'),
            ),
            const SizedBox(height: 8),
            ElevatedButton(
              key: const Key('buggy-button'),
              onPressed: _click,
              child: const Text('Click me'),
            ),
          ],
        ),
      ),
    );
  }
}

class Countdown extends StatefulWidget {
  const Countdown({super.key});

  @override
  State<Countdown> createState() => _CountdownState();
}

class _CountdownState extends State<Countdown> {
  late int _left;
  Timer? _timer;
  int _builds = 0;

  @override
  void initState() {
    super.initState();

    lifecycleLog.add('initState');
    _left = startSeconds;

    _timer = Timer.periodic(
      const Duration(seconds: 1),
      (timer) {
        if (!mounted) {
          timer.cancel();
          return;
        }

        if (_left > 0) {
          setState(() {
            _left--;
          });
        }

        if (_left <= 0) {
          timer.cancel();
        }
      },
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    lifecycleLog.add('dispose');
    debugPrint('Lifecycle log: $lifecycleLog');
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    _builds++;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Countdown',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _left > 0 ? 'Time left: $_left s' : 'Time is up!',
              key: const Key('time-left'),
            ),
            Text(
              'Builds: $_builds',
              key: const Key('builds'),
            ),
          ],
        ),
      ),
    );
  }
}
